<?php

    return [
        'APP_NAME' => 'Ekolo Framework',
        
        'APP_DEFAULT_LAYOUT_PAGE' => 'layout',

        'APP_DEFAULT_LAYOUT_ERROR' => 'error'
    ];