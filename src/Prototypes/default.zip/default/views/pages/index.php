<div class="ekolo-container">
    <img src="/public/img/ekolo-logo.png" alt="Logo de Ekolo Framework" width="350px" />

    <p><a href="http://www.ekoloframework.org">&copy; Ekolo Framework Foundation <?= date('Y') ?></a></p>
</div>